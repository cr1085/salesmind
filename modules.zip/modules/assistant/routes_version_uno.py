from flask import Blueprint, request, jsonify
from flask_login import login_required
from .core import AIAssistant
from .rag_processor import RAGProcessor # <-- IMPORTAR

assistant_bp = Blueprint('assistant', __name__)
ai_assistant = AIAssistant()
rag_processor = RAGProcessor() # <-- INICIALIZAR

@assistant_bp.route('/ask', methods=['POST'])
@login_required
def ask():
    data = request.get_json()
    question = data.get('question')

    if not question:
        return jsonify({'error': 'No se proporcionó ninguna pregunta.'}), 400
    
    # --- ¡LA MAGIA DEL RAG! ---
    # 1. Buscar contexto relevante en nuestros documentos
    context = rag_processor.get_relevant_context(question)
    print(f"DEBUG: Contexto encontrado para la pregunta:\n---\n{context}\n---")

    # 2. Crear un nuevo prompt aumentado con el contexto
    if context:
        # Si encontramos contexto, le pedimos a la IA que lo use
        prompt = f"""
        Basándote únicamente en el siguiente contexto extraído de documentos legales, responde la pregunta del usuario.
        Si la respuesta no está en el contexto, di "La información no se encuentra en los documentos que he procesado."

        ---
        Contexto:
        {context}
        ---

        Pregunta del usuario: {question}
        """
    else:
        # Si no hay contexto, la pregunta va directa a la IA
        prompt = question

    response_text = ai_assistant.get_response(question)
    
    return jsonify({'response': response_text})