import fitz  # PyMuPDF
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import os

# ---- CONFIGURACIÓN ----
# Directorio para guardar el almacén de vectores y los metadatos
STORE_PATH = 'instance/vector_store'
# Modelo para crear los embeddings. 'all-MiniLM-L6-v2' es rápido y bueno.
EMBEDDING_MODEL = 'all-MiniLM-L6-v2'
# Tamaño de los fragmentos de texto (en caracteres)
CHUNK_SIZE = 1000
# Solapamiento entre fragmentos para no perder contexto
CHUNK_OVERLAP = 100

class RAGProcessor:
    def __init__(self):
        # Asegurarse de que el directorio de almacenamiento exista
        os.makedirs(STORE_PATH, exist_ok=True)

        # Cargar el modelo de embeddings una sola vez
        self.model = SentenceTransformer(EMBEDDING_MODEL)

        # Cargar el índice FAISS si existe, si no, se creará uno nuevo
        self.index_path = os.path.join(STORE_PATH, 'documents.index')
        self.metadata_path = os.path.join(STORE_PATH, 'documents.txt')

        if os.path.exists(self.index_path):
            self.index = faiss.read_index(self.index_path)
            with open(self.metadata_path, 'r', encoding='utf-8') as f:
                self.metadata = f.read().splitlines()
        else:
            # El tamaño del vector para 'all-MiniLM-L6-v2' es 384
            self.index = faiss.IndexFlatL2(384) 
            self.metadata = []

    def _extract_text_from_pdf(self, pdf_path):
        """Extrae texto de un archivo PDF."""
        doc = fitz.open(pdf_path)
        text = ""
        for page in doc:
            text += page.get_text()
        return text

    def _chunk_text(self, text):
        """Divide el texto en fragmentos solapados."""
        chunks = []
        start = 0
        while start < len(text):
            end = start + CHUNK_SIZE
            chunks.append(text[start:end])
            start += CHUNK_SIZE - CHUNK_OVERLAP
        return chunks

    def process_document(self, file_path, original_filename):
        """Procesa un documento: extrae, fragmenta, vectoriza y guarda."""
        print(f"Procesando el documento: {original_filename}")

        # 1. Extraer texto
        text = self._extract_text_from_pdf(file_path)

        # 2. Dividir en fragmentos (chunks)
        chunks = self._chunk_text(text)

        # 3. Convertir fragmentos a vectores (embeddings)
        embeddings = self.model.encode(chunks, convert_to_tensor=False)

        # 4. Añadir al índice FAISS y a los metadatos
        self.index.add(np.array(embeddings).astype('float32'))
        for chunk in chunks:
            # Guardamos el chunk y el nombre del archivo de origen
            self.metadata.append(f"{original_filename}::{chunk.replace(os.linesep, ' ')}")

        # 5. Guardar el índice y los metadatos en el disco
        faiss.write_index(self.index, self.index_path)
        with open(self.metadata_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(self.metadata))

        print(f"Documento '{original_filename}' procesado y añadido al índice.")

    def get_relevant_context(self, query, top_k=3):
        """Encuentra los fragmentos de texto más relevantes para una consulta."""
        if not self.metadata:
            return "" # No hay documentos procesados

        # Convertir la consulta a vector
        query_embedding = self.model.encode([query])

        # Buscar en el índice FAISS los k fragmentos más cercanos
        distances, indices = self.index.search(np.array(query_embedding).astype('float32'), top_k)

        # Recopilar el texto de los fragmentos encontrados
        context = [self.metadata[i] for i in indices[0]]

        # Formatear el contexto para el LLM
        return "\n\n---\n\n".join(context)