import fitz  # PyMuPDF
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import os
import unicodedata

# ---- CONFIGURACIÓN MEJORADA ----
STORE_PATH = 'instance/vector_store'
EMBEDDING_MODEL = 'sentence-transformers/paraphrase-multilingual-mpnet-base-v2'
CHUNK_SIZE = 1000
CHUNK_OVERLAP = 100

def normalize_text(text):
    """Convierte texto a minúsculas y remueve acentos."""
    return ''.join(
        c for c in unicodedata.normalize('NFD', text.lower())
        if unicodedata.category(c) != 'Mn'
    )

class RAGProcessor:
    def __init__(self):
        os.makedirs(STORE_PATH, exist_ok=True)
        self.model = SentenceTransformer(EMBEDDING_MODEL)
        self.index_path = os.path.join(STORE_PATH, 'documents.index')
        self.metadata_path = os.path.join(STORE_PATH, 'documents.txt')
        
        if os.path.exists(self.index_path):
            self.index = faiss.read_index(self.index_path)
            with open(self.metadata_path, 'r', encoding='utf-8') as f:
                self.metadata = f.read().splitlines()
        else:
            self.index = faiss.IndexFlatL2(768)
            self.metadata = []

    def _extract_text_from_pdf(self, pdf_path):
        doc = fitz.open(pdf_path)
        text = ""
        for page in doc:
            text += page.get_text()
        return text

    def _chunk_text(self, text):
        chunks = []
        start = 0
        while start < len(text):
            end = start + CHUNK_SIZE
            chunks.append(text[start:end])
            start += CHUNK_SIZE - CHUNK_OVERLAP
        return chunks

    # def process_document(self, file_path, original_filename):
    #     print(f"Procesando el documento: {original_filename}")
    #     text = self._extract_text_from_pdf(file_path)
    #     chunks = self._chunk_text(text)
        
    #     # Normalizamos el texto ANTES de crear los embeddings
    #     normalized_chunks = [normalize_text(chunk) for chunk in chunks]
    #     embeddings = self.model.encode(normalized_chunks, convert_to_tensor=False)
        
    #     self.index.add(np.array(embeddings).astype('float32'))
        
    #     # Guardamos los chunks originales en los metadatos
    #     for chunk in chunks:
    #         self.metadata.append(f"{original_filename}::{chunk.replace(os.linesep, ' ')}")
        
    #     faiss.write_index(self.index, self.index_path)
    #     with open(self.metadata_path, 'w', encoding='utf-8') as f:
    #         f.write('\n'.join(self.metadata))
    #     print(f"Documento '{original_filename}' procesado y añadido al índice.")

        # En modules/assistant/rag_processor.py
    
    def process_document(self, file_path, original_filename):
        print(f"Procesando el documento: {original_filename}")
        text = self._extract_text_from_pdf(file_path)
        chunks = self._chunk_text(text)
        
        normalized_chunks = [normalize_text(chunk) for chunk in chunks]
        
        # --- INICIO DE LA SOLUCIÓN ---
        # Procesamos los embeddings en lotes para no saturar la memoria de la GPU.
        # También mostramos una barra de progreso en la terminal.
        print(f"Creando embeddings para {len(normalized_chunks)} fragmentos...")
        embeddings = self.model.encode(
            normalized_chunks, 
            batch_size=32,          # Puedes ajustar este número (32 es un buen punto de partida)
            show_progress_bar=True, # ¡Esto mostrará una barra de progreso en la consola!
            convert_to_tensor=False
        )
        # --- FIN DE LA SOLUCIÓN ---
        
        self.index.add(np.array(embeddings).astype('float32'))
        
        # Guardamos los chunks originales en los metadatos
        for chunk in chunks:
            self.metadata.append(f"{original_filename}::{chunk.replace(os.linesep, ' ')}")
        
        faiss.write_index(self.index, self.index_path)
        with open(self.metadata_path, 'w', encoding='utf-8') as f:
            f.write('\n'.join(self.metadata))
        print(f"Documento '{original_filename}' procesado y añadido al índice.")

    def get_relevant_context(self, query, top_k=5, min_similarity=0.0):
        """Encuentra contexto relevante con normalización y un umbral de similitud."""
        if not self.metadata:
            return ""
        
        # Normalizamos la consulta del usuario
        normalized_query = normalize_text(query)
        query_embedding = self.model.encode([normalized_query])
        
        # Buscamos en el índice FAISS (que ahora contiene vectores de texto normalizado)
        distances, indices = self.index.search(np.array(query_embedding).astype('float32'), top_k)
        
        # La distancia en L2 se puede convertir a una "similitud" simple para filtrado
        # (Esta es una simplificación, pero efectiva para empezar)
        similarity = 1 - (distances[0] / np.max(distances[0] + 1e-6))
        
        # Filtramos los resultados que no son lo suficientemente buenos
        relevant_indices = [indices[0][i] for i, s in enumerate(similarity) if s >= min_similarity]
        
        if not relevant_indices:
            return "" # No se encontró nada con la similitud mínima

        context = [self.metadata[i] for i in relevant_indices]
        return "\n\n---\n\n".join(context)