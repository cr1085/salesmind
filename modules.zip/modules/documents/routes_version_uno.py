from flask import Blueprint, render_template, request, flash, redirect, url_for
from flask_login import login_required
import os
from werkzeug.utils import secure_filename
from modules.assistant.rag_processor import RAGProcessor

documents_bp = Blueprint('documents', __name__)
rag_processor = RAGProcessor()
UPLOAD_FOLDER = 'instance/uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@documents_bp.route('/upload', methods=['GET', 'POST'])
@login_required
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            flash('No se encontró el archivo', 'error')
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            flash('No se seleccionó ningún archivo', 'error')
            return redirect(request.url)
        if file and file.filename.endswith('.pdf'):
            filename = secure_filename(file.filename)
            filepath = os.path.join(UPLOAD_FOLDER, filename)
            file.save(filepath)
            
            # Procesar el documento con nuestro RAGProcessor
            try:
                rag_processor.process_document(filepath, filename)
                flash(f'¡Archivo "{filename}" cargado y procesado exitosamente!', 'success')
            except Exception as e:
                flash(f'Error al procesar el archivo: {e}', 'error')

            return redirect(url_for('documents.upload_file'))

    return render_template('upload.html')