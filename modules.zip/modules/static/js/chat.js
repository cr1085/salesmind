document.addEventListener('DOMContentLoaded', () => {
    const chatContainer = document.getElementById('chat-container');
    if (!chatContainer) {
        return;
    }

    const sendBtn = document.getElementById('send-btn');
    const userInput = document.getElementById('user-input');
    const chatBox = document.getElementById('chat-box');

    const sendMessage = async () => {
        const question = userInput.value.trim();
        if (!question) return;

        addMessage(question, 'user');
        userInput.value = '';

        const thinkingMessage = addMessage('Pensando...', 'assistant', true);

        try {
            const response = await fetch('/ask', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ question: question })
            });

            if (!response.ok) {
                throw new Error('Error en la respuesta del servidor.');
            }

            const data = await response.json();
            
            // Eliminamos el mensaje de "Pensando..."
            chatBox.removeChild(thinkingMessage);

            // --- INICIO DE LA MEJORA ---
            // Si el servidor nos envió un contexto, lo mostramos.
            if (data.context) {
                addContextBlock(data.context);
            }
            // --- FIN DE LA MEJORA ---

            // Mostramos la respuesta final de la IA
            addMessage(data.response, 'assistant');

        } catch (error) {
            console.error('Error:', error);
            thinkingMessage.innerText = 'Lo siento, hubo un error al contactar al asistente.';
        }
    };

    const addMessage = (text, sender, isThinking = false) => {
        const messageElement = document.createElement('div');
        messageElement.classList.add('message', `${sender}-message`);
        messageElement.innerText = text;
        if (isThinking) {
            messageElement.classList.add('thinking');
        }
        chatBox.appendChild(messageElement);
        chatBox.scrollTop = chatBox.scrollHeight;
        return messageElement;
    };

    // --- INICIO DE LA NUEVA FUNCIÓN ---
    // Esta función crea el bloque visual para el contexto.
    const addContextBlock = (contextText) => {
        const contextElement = document.createElement('div');
        contextElement.classList.add('context-block');
        
        const title = document.createElement('h4');
        title.innerText = 'Fuente de la Información (Contexto del Documento)';
        
        const content = document.createElement('p');
        // Limpiamos el texto para que sea más legible
        const cleanContext = contextText.replace(/Fuente:.*?::/, '').trim();
        content.innerText = cleanContext;

        contextElement.appendChild(title);
        contextElement.appendChild(content);
        chatBox.appendChild(contextElement);
    };
    // --- FIN DE LA NUEVA FUNCIÓN ---

    sendBtn.addEventListener('click', sendMessage);
    userInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });
});